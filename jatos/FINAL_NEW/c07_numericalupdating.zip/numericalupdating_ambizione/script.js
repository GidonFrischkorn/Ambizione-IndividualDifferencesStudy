// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "NumericalUpdating_Ambizione",
    "description": "",
    "repository": "",
    "contributors": "Gidon Frischkorn \u003Cgidon.frischkorn@psychologie.uzh.ch\u003E"
  },
  "messageHandlers": {
    "epilogue": function anonymous(
) {
var resultJson = study.options.datastore.exportJson();
jatos.submitResultData(resultJson, jatos.startNextComponent);
}
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.html.Form",
      "content": " \u003Cstyle\u003E\n    h1 {\n      font-size: 1.5rem;\n      font-color: black;\n    }\n    label {\n      display: block;\n      margin-top: 1rem;\n      font-weight: bold;\n    }\n    input {\n      padding: 0.5rem;\n      font-size: 1rem;\n      width: 100px;\n      max-width: 100%;\n    }\n    button {\n      margin-top: 2rem;\n      padding: 0.75rem 1.5rem;\n      font-size: 1rem;\n      cursor: pointer;\n    }\n  \u003C\u002Fstyle\u003E\n\n\n\u003Ch2\u003ENumerical Updating Aufgabe\u003C\u002Fh2\u003E\n\n\u003Ch2\u003EBitte generieren Sie Ihren Teilnehmercode aus den folgenden Informationen:\u003C\u002Fh2\u003E\n\n\n\u003Cform\u003E\n  \u003Clabel for=\"letter-firstname\"\u003E\n      Dem letzten Buchstaben Ihres eigenen Vornamens\n    \u003C\u002Flabel\u003E\n    \u003Cinput type=\"text\" id=\"letter-firstname\" name=\"letter-firstname\" maxlength=\"1\" required\u003E\n\n    \u003Clabel for=\"letter-lastname\"\u003E\n      Dem letzten Buchstaben Ihres eigenen Nachnamens\n    \u003C\u002Flabel\u003E\n    \u003Cinput type=\"text\" id=\"letter-lastname\" name=\"letter-lastname\" maxlength=\"1\" required\u003E\n\n    \u003Clabel for=\"letter-mother\"\u003E\n      Dem zweiten Buchstaben des Vornamens Ihrer Mutter\n    \u003C\u002Flabel\u003E\n    \u003Cinput type=\"text\" id=\"letter-mother\" name=\"letter-mother\" maxlength=\"1\" required\u003E\n\n    \u003Clabel for=\"letter-father\"\u003E\n      Dem zweiten Buchstaben des Vornamens Ihres Vaters\n    \u003C\u002Flabel\u003E\n    \u003Cinput type=\"text\" id=\"letter-father\" name=\"letter-father\" maxlength=\"1\" required\u003E\n\n    \u003Clabel for=\"digit-birthdate\"\u003E\n      Der zweiten Ziffer Ihres Geburtstages (bei einstelligen Tagen die Ziffer selbst)\n    \u003C\u002Flabel\u003E\n    \u003Cinput type=\"number\" id=\"digit-birthdate\" name=\"digit-birthdate\" min=\"0\" max=\"9\" required\u003E\n\n    \u003Clabel for=\"digit-birthyear\"\u003E\n      Der letzten Ziffer Ihres Geburtsjahres\n    \u003C\u002Flabel\u003E\n    \u003Cinput type=\"number\" id=\"digit-birthyear\" name=\"digit-birthyear\" min=\"0\" max=\"9\" required\u003E\n\n    \u003Cbutton type=\"submit\"\u003EAbsenden\u003C\u002Fbutton\u003E\n\u003C\u002Fform\u003E",
      "scrollTop": true,
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
window.id = this.random.uuid4() 

// get screenparms
window.xPixels = window.outerWidth
window.yPixels = window.outerHeight  
window.dpiSetting = window.devicePixelRatio

// define parameters
stims_num = [1, 2, 3, 4, 5, 6, 7, 8, 9]
stims_char = ["1", "2", "3", "4", "5", "6", "7", "8", "9"]

updating_ops_char = ["-2","-1","+1","+2"] 

locs_numeriert = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]
window.locs = [[-120,-120],[-40,-120],[+40,-120], [+120, -120], [-120,-40], [-40,-40], [+40, -40], [+120, -40], [-120, +40], [-40, +40], [+40, +40], [+120, +40], [-120, +120], [-40, +120], [+40, +120], [+120, +120]]

// Define experimental conditions
setsizes = [4,5]
recall = ["stimulus"]
updating_steps = [3]

trial2conds = 8
trial2prac = 1
window.numTrials = trial2conds * setsizes.length * recall.length * updating_steps.length
window.numPracTrials = trial2prac * setsizes.length * recall.length * updating_steps.length

// pre-allocate trial_list
trial_list = []
practice_trial_list = []

// loop through setsizes
for(i = 0; i < setsizes.length; ++i){
  // loop through recall options
  for(j = 0; j < recall.length; ++j){
    // loop through updating step conditions
    for(k = 0; k < updating_steps.length; ++k){
      // loop through trials
      for(l = 0; l < trial2conds; ++l){
        // randomize stimuli and locations for each trial
        rand_stims = this.random.shuffle(stims_num)
        rand_locs = this.random.shuffle(locs_numeriert)
        
        // pre-allocate empty trial object
        trial = []

        // specify variables constant within a trial
        trial_setsize = setsizes[i]
        trial_rec = recall[j]
        trial_updatingSteps = updating_steps[k]
        
        // pre-allocate empty variables for stimuli and locations
        trial_stims = []
        trial_stims_char = []
        trial_locs = []

        // loop through each memory item (position)
        for(m=0; m < trial_setsize; ++m){
          // select stimulus for each memory item
          pos_stim = rand_stims[0]
          rand_stims.splice(0,1)
          trial_stims.push(pos_stim)

          pos_stim_char = stims_char[stims_num.indexOf(pos_stim)]
          trial_stims_char.push(pos_stim_char)

          // select spatial position for each memory item
          pos_loc = rand_locs[0]
          rand_locs.splice(0,1)
          trial_locs.push(pos_loc)
        }

        // specify encoding and retriaval order
        encodingOrder = Array(trial_setsize).fill().map((element, index) => index + 1)
        retrievalOrder = this.random.shuffle(encodingOrder)

        // specify updating steps
        trial_updOps = []
        trial_updOps_char = []
        trial_updPos = []
        trial_finalStims = trial_stims.slice()
        for(n = 0; n < trial_updatingSteps; ++n){
          // get random memory item
          updatedPos = Math.floor(Math.random() * encodingOrder.length)
          trial_updPos[n] = updatedPos

          // get random updating operation
          if(trial_finalStims[updatedPos] == 1){
            updating_ops = [+1,+2]
            updating_ops_char = ["+1","+2"]
            randIdx = Math.floor(Math.random() * updating_ops.length)
            trial_updOps[n] = updating_ops[randIdx]
            trial_updOps_char[n] = updating_ops_char[randIdx]
          }else if(trial_finalStims[updatedPos] == 2){
            updating_ops = [-1,+1,+2]
            updating_ops_char = ["-1","+1","+2"]
            randIdx = Math.floor(Math.random() * updating_ops.length)
            trial_updOps[n] = updating_ops[randIdx]
            trial_updOps_char[n] = updating_ops_char[randIdx]
          }else if(trial_finalStims[updatedPos] == 8){
            updating_ops = [-2,-1,+1]
            updating_ops_char = ["-2","-1","+1"]
            randIdx = Math.floor(Math.random() * updating_ops.length)
            trial_updOps[n] = updating_ops[randIdx]
            trial_updOps_char[n] = updating_ops_char[randIdx]
          }else if(trial_finalStims[updatedPos] == 9){
            updating_ops = [-2,-1]
            updating_ops_char = ["-2","-1"]
            randIdx = Math.floor(Math.random() * updating_ops.length)
            trial_updOps[n] = updating_ops[randIdx]
            trial_updOps_char[n] = updating_ops_char[randIdx]
          }else{
            updating_ops = [-2,-1,+1,+2]
            updating_ops_char = ["-2","-1","+1","+2"]
            randIdx = Math.floor(Math.random() * updating_ops.length)
            trial_updOps[n] = updating_ops[randIdx]
            trial_updOps_char[n] = updating_ops_char[randIdx]
          }
          
          trial_finalStims[updatedPos] = trial_finalStims[updatedPos] + updating_ops[randIdx]
        }

        // push all info to the trial
        trial.push(trial_setsize,trial_rec,trial_stims,trial_locs,encodingOrder,retrievalOrder,trial_updatingSteps,trial_updOps,trial_updOps_char,trial_updPos,trial_finalStims)

        // push trial info to setsize_list
        trial_list.push(trial)
      }
    }
  }
}

// loop through setsizes
for(i = 0; i < setsizes.length; ++i){
  // loop through recall options
  for(j = 0; j < recall.length; ++j){
    // loop through updating step conditions
    for(k = 0; k < updating_steps.length; ++k){
      // loop through trials
      for(l = 0; l < trial2prac; ++l){
        // randomize stimuli and locations for each trial
        rand_stims = this.random.shuffle(stims_num)
        rand_locs = this.random.shuffle(locs_numeriert)
        
        // pre-allocate empty trial object
        trial = []

        // specify variables constant within a trial
        trial_setsize = setsizes[i]
        trial_rec = recall[j]
        trial_updatingSteps = updating_steps[k]
        
        // pre-allocate empty variables for stimuli and locations
        trial_stims = []
        trial_stims_char = []
        trial_locs = []

        // loop through each memory item (position)
        for(m=0; m < trial_setsize; ++m){
          // select stimulus for each memory item
          pos_stim = rand_stims[0]
          rand_stims.splice(0,1)
          trial_stims.push(pos_stim)

          pos_stim_char = stims_char[stims_num.indexOf(pos_stim)]
          trial_stims_char.push(pos_stim_char)

          // select spatial position for each memory item
          pos_loc = rand_locs[0]
          rand_locs.splice(0,1)
          trial_locs.push(pos_loc)
        }

        // specify encoding and retriaval order
        encodingOrder = Array(trial_setsize).fill().map((element, index) => index + 1)
        retrievalOrder = this.random.shuffle(encodingOrder)

        // specify updating steps
        trial_updOps = []
        trial_updOps_char = []
        trial_updPos = []
        trial_finalStims = trial_stims.slice()
        for(n = 0; n < trial_updatingSteps; ++n){
          // get random memory item
          updatedPos = Math.floor(Math.random() * encodingOrder.length)
          trial_updPos[n] = updatedPos

          // get random updating operation
          if(trial_finalStims[updatedPos] == 1){
            updating_ops = [+1,+2]
            updating_ops_char = ["+1","+2"]
            randIdx = Math.floor(Math.random() * updating_ops.length)
            trial_updOps[n] = updating_ops[randIdx]
            trial_updOps_char[n] = updating_ops_char[randIdx]
          }else if(trial_finalStims[updatedPos] == 2){
            updating_ops = [-1,+1,+2]
            updating_ops_char = ["-1","+1","+2"]
            randIdx = Math.floor(Math.random() * updating_ops.length)
            trial_updOps[n] = updating_ops[randIdx]
            trial_updOps_char[n] = updating_ops_char[randIdx]
          }else if(trial_finalStims[updatedPos] == 8){
            updating_ops = [-2,-1,+1]
            updating_ops_char = ["-2","-1","+1"]
            randIdx = Math.floor(Math.random() * updating_ops.length)
            trial_updOps[n] = updating_ops[randIdx]
            trial_updOps_char[n] = updating_ops_char[randIdx]
          }else if(trial_finalStims[updatedPos] == 9){
            updating_ops = [-2,-1]
            updating_ops_char = ["-2","-1"]
            randIdx = Math.floor(Math.random() * updating_ops.length)
            trial_updOps[n] = updating_ops[randIdx]
            trial_updOps_char[n] = updating_ops_char[randIdx]
          }else{
            updating_ops = [-2,-1,+1,+2]
            updating_ops_char = ["-2","-1","+1","+2"]
            randIdx = Math.floor(Math.random() * updating_ops.length)
            trial_updOps[n] = updating_ops[randIdx]
            trial_updOps_char[n] = updating_ops_char[randIdx]
          }
          
          trial_finalStims[updatedPos] = trial_finalStims[updatedPos] + updating_ops[randIdx]
        }

        // push all info to the trial
        trial.push(trial_setsize,trial_rec,trial_stims,trial_locs,encodingOrder,retrievalOrder,trial_updatingSteps,trial_updOps,trial_updOps_char,trial_updPos,trial_finalStims)

        // push trial info to setsize_list
        practice_trial_list.push(trial)
      }
    }
  }
}

// randomize the trial_list and make it globally available
window.final_trial_list = this.random.shuffle(trial_list)

// randomize the trial_list and make it globally available
window.final_practice_trial_list = practice_trial_list

// print out the trial list to the console
console.log('Trial List: ',window.final_trial_list)
console.log('Practice Trial List: ',window.final_practice_trial_list)

// Instructions
window.picture_ind = 0
window.picture_list = []
window.all_picture = false

picture_list = []
pic_name1 = "<img src='static/Slide1.png' width=1000 height=750>"
pic_name2 = "<img src='static/Slide2.png' width=1000 height=750>"
pic_name3 = "<img src='static/Slide3.png' width=1000 height=750>"
pic_name4 = "<img src='static/Slide4.png' width=1000 height=750>"
pic_name5 = "<img src='static/Slide5.png' width=1000 height=750>"
picture_list.push(pic_name1,pic_name2, pic_name3, pic_name4, pic_name5)

window.picture_list = picture_list
window.instr_ind = 0
window.all_instr = false

},
        "after:end": function anonymous(
) {
console.log(this.data["digit-birthdate"])

const letters_code = this.data["letter-firstname"] + this.data["letter-lastname"] + this.data["letter-mother"] + this.data["letter-father"]; 
const digits1 = this.data["digit-birthdate"];
const digits2 = this.data["digit-birthyear"];

const participant_id = letters_code.toUpperCase() + digits1 + digits2;

window.participant_id = participant_id;
console.log(participant_id);

this.options.datastore["participant_id"] = participant_id;
// study.options.parameter.participant_id = participant_id;

console.log(this.data["participant_id"])

this.data.random_id = window.id
this.data.participant_id = participant_id
this.data.dpi = window.dpiSetting
this.data.xPixels = window.xPixels
this.data.yPixels = window.yPixels
}
      },
      "title": "Form"
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "": ""
        }
      ],
      "sample": {
        "mode": "sequential",
        "n": "100"
      },
      "files": {
        "Instruktion3.png": "embedded\u002F316603e7a8d418b6b855f4c4615f79e531f7d7be8268f0dc28c34fb5e106ab6b.png",
        "Instruktion4.png": "embedded\u002F2dec890b1253858836c57a810ecd761e642bc175dd31384dd04dbd5239891ec2.png"
      },
      "responses": {
        "click button#instr": "submit"
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instruction Loop",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {
          "Instruktion3.png": "embedded\u002F316603e7a8d418b6b855f4c4615f79e531f7d7be8268f0dc28c34fb5e106ab6b.png",
          "Instruktion4.png": "embedded\u002F2dec890b1253858836c57a810ecd761e642bc175dd31384dd04dbd5239891ec2.png"
        },
        "responses": {
          "": ""
        },
        "parameters": {},
        "messageHandlers": {},
        "title": "Sequence",
        "tardy": true,
        "content": [
          {
            "type": "lab.html.Screen",
            "files": {},
            "responses": {
              "keypress(l)": "forth",
              "keypress(k)": "back",
              "keydown(ArrowRight)": "forth",
              "keydown(ArrowLeft)": "back"
            },
            "parameters": {},
            "messageHandlers": {
              "end": function anonymous(
) {
if (this.data.response == "back") {
  if (instr_ind > 0) {
    --instr_ind
  } else {
    instr_ind = instr_ind
  }
} else if (this.data.response == "forth") {
  if (instr_ind < (picture_list.length-1)) {
    ++instr_ind
  } else {
    ++instr_ind
    all_instr = true
  }
}









},
              "before:prepare": function anonymous(
) {
window.pic = window.picture_list[instr_ind]
}
            },
            "title": "Display Instructions (required)",
            "content": "\u003Cstyle\u003E\n#div1{width: 900px;text-align:  center;}\n#div2{width: 900px; text-align: left;}\nheader{padding: 5px; height: 100px;}\nfooter{padding: 5px; height: 120px;}\nlabel {\n  width:200px;\n  display: inline-block;\n}\n\u003C\u002Fstyle\u003E\n\n\u003Cheader\u003E\n  \u003Ch1\u003E Instructions \u003C\u002Fh1\u003E\n\u003C\u002Fheader\u003E\n\n\n\u003Cmain class=\"content-horizontal-center\"\u003E\n  \u003Cform\u003E\n    \u003Cdiv id = \"div1\"\u003E\n      \u003Cp\u003E\n        ${window.pic}\n      \u003C\u002Fp\u003E\n    \u003C\u002Fdiv\u003E\n  \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n\n\u003Cfooter\u003E\n  \u003Cp\u003EUm zur nächsten Seite zu gehen, drücken Sie \n    \u003Ckbd\u003EL\u003C\u002Fkbd\u003E oder \u003Ckbd\u003E&rarr;\u003C\u002Fkbd\u003E.\u003C\u002Fp\u003E\n    \u003Cp\u003EUm zu einer vorherigen Seite zurück zu kehren, drücken Sie\n       \u003Ckbd\u003Ek\u003C\u002Fkbd\u003E oder \u003Ckbd\u003E&larr;\u003C\u002Fkbd\u003E.\u003C\u002Fp\u003E\n\u003C\u002Ffooter\u003E",
            "skip": "${ window.all_instr }",
            "tardy": true
          },
          {
            "type": "lab.html.Screen",
            "files": {},
            "responses": {
              "keypress(k)": "back",
              "keypress(l)": "forth",
              "click button#bend": "submit"
            },
            "parameters": {},
            "messageHandlers": {
              "end": function anonymous(
) {
if (this.data.response == "back") {
  if (instr_ind > 0) {
    --instr_ind
  } else {
    instr_ind = instr_ind
  }
} else if (this.data.response == "forth") {
  if (instr_ind < (picture_list.length-1)) {
    ++instr_ind
  } else {
    instr_ind = instr_ind
  }
}

if (this.data.response == "submit") {
  this.parent.end()
  this.parent.parent.end()
}
}
            },
            "title": "Display Instructions (possible)",
            "content": "\u003Cstyle\u003E\n#div1{width: 900px;text-align:  center;}\n#div2{width: 900px; text-align: left;}\nheader{ padding: 5px; height: 100px;}\nfooter{ padding: 5px; height: 120px;}\nlabel {\n  width:200px;\n  display: inline-block;\n}\n\u003C\u002Fstyle\u003E\n\n\u003Cheader\u003E\n  \u003Ch1\u003E Instruktionen \u003C\u002Fh1\u003E\n\u003C\u002Fheader\u003E\n\n\n\u003Cmain class=\"content-horizontal-center\"\u003E\n  \u003Cform\u003E\n    \u003Cdiv id = \"div1\"\u003E\n      \u003Cp\u003E\n        ${window.pic}\n      \u003C\u002Fp\u003E\n    \u003C\u002Fdiv\u003E\n\n    \n  \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n\n\u003Cfooter\u003E\n  \u003Ctable class = \"table-plain;margin-left:auto;margin-right:auto;\"\u003E\n    \u003Ctr\u003E\n      \u003Ctd style = \"text-align: right;width:20%\"\u003E\n        \u003Cp\u003E\n        \u003Cbutton id = \"bend\" type = \"submit\"\u003E\n          Mit dem Experiment starten.\n        \u003C\u002Fbutton\u003E\u003C\u002Fp\u003E\n      \u003C\u002Ftd\u003E\n    \u003C\u002Ftr\u003E\n  \u003C\u002Ftable\u003E\n\u003C\u002Ffooter\u003E",
            "skip": "${ !window.all_instr }",
            "tardy": true
          }
        ]
      }
    },
    {
      "type": "lab.flow.Sequence",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
window.prac_trial_ind = 0
window.trial_ind = 0
}
      },
      "title": "Experiment Sequence",
      "content": [
        {
          "type": "lab.canvas.Screen",
          "content": [
            {
              "type": "i-text",
              "left": 0,
              "top": 0,
              "angle": 0,
              "width": 771.11,
              "height": 247.33,
              "stroke": null,
              "strokeWidth": 1,
              "fill": "black",
              "text": "Bevor das Experiment beginnt, erhalten Sie nun \neinige Übungsdurchgänge, um sich mit der Aufgabe vertraut zu machen.\n \nNach Ihrer Antwort erhalten Sie dabei jeweils \neine Rückmeldung, ob Ihre Antwort richtig war oder nicht. \nDas Feedback wird nur bei den Übungsversuchen angezeigt. \n\nDrücken Sie die \"Leertaste\", um mit den Übungsversuchen zu beginnen.",
              "fontStyle": "normal",
              "fontWeight": "normal",
              "fontSize": "24",
              "fontFamily": "sans-serif",
              "lineHeight": 1.16,
              "textAlign": "center"
            }
          ],
          "viewport": [
            800,
            600
          ],
          "files": {},
          "responses": {
            "keypress(Space)": "End"
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "StartPrac_Inst"
        },
        {
          "type": "lab.flow.Loop",
          "templateParameters": [
            {
              "": ""
            }
          ],
          "sample": {
            "mode": "sequential",
            "n": "${window.numPracTrials}"
          },
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "Practice Trial Loop",
          "shuffleGroups": [],
          "template": {
            "type": "lab.flow.Sequence",
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {
              "before:prepare": function anonymous(
) {
this_trial = window.final_practice_trial_list[window.prac_trial_ind]

// initialize the encoding and retrieval positions
window.encodingposition = 0
window.retrievalposition = 0
window.updatingStep = 0

// make trial variables available in each trial
window.setsize = this_trial[0]
window.rec = this_trial[1]
window.encStimuli = this_trial[2]
window.encLocations = this_trial[3]
window.encOrder = this_trial[4]
window.retOrder = this_trial[5]

window.updSteps = this_trial[6]
window.updOps_char = this_trial[8]
window.updOps_loc = []
for(k = 0; k < window.updSteps; ++k){
  upd_Locs = this_trial[9]
  loc_Idx = upd_Locs[k]
  window.updOps_loc[k] = window.encLocations[loc_Idx]
}
window.finalStims = this_trial[10]

// iterate to the next trial
++window.prac_trial_ind
}
            },
            "title": "Trial Sequence",
            "tardy": true,
            "content": [
              {
                "type": "lab.canvas.Screen",
                "content": [],
                "viewport": [
                  800,
                  600
                ],
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "StartTrialBlank",
                "timeout": "1000"
              },
              {
                "type": "lab.flow.Loop",
                "templateParameters": [
                  {
                    "": ""
                  }
                ],
                "sample": {
                  "mode": "sequential",
                  "n": "${window.setsize}"
                },
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "Encoding Loop",
                "shuffleGroups": [],
                "template": {
                  "type": "lab.flow.Sequence",
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {
                    "before:prepare": function anonymous(
) {
// extract encoding position
window.encPos = window.encOrder[encodingposition]

// get letter for current position
window.letter = window.encStimuli[window.encPos -1] 

// get location for current position
window.loc_num = window.encLocations[window.encPos -1]
window.loc = window.locs[window.loc_num-1]

// Print out some information if necessary
//console.log('Current Stimulus: ', window.letter)
//console.log('Current Locations: ' , window.loc)

//console.log("Current Position: ", window.encodingposition)
++window.encodingposition
//console.log("Next Position: ", window.encodingposition)
}
                  },
                  "title": "Encoding Sequence",
                  "tardy": true,
                  "content": [
                    {
                      "type": "lab.canvas.Screen",
                      "content": [
                        {
                          "type": "rect",
                          "left": "${x1}",
                          "top": "${y1}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x2}",
                          "top": "${y2}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x3}",
                          "top": "${y3}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x4}",
                          "top": "${y4}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x5}",
                          "top": "${y5}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x6}",
                          "top": "${x6}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x7}",
                          "top": "${y7}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x8}",
                          "top": "${y8}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x9}",
                          "top": "${y9}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x10}",
                          "top": "${y10}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x11}",
                          "top": "${y11}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x12}",
                          "top": "${y12}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x13}",
                          "top": "${y13}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x14}",
                          "top": "${y14}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x15}",
                          "top": "${y15}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x16}",
                          "top": "${y16}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        }
                      ],
                      "viewport": [
                        800,
                        600
                      ],
                      "files": {},
                      "responses": {
                        "": ""
                      },
                      "parameters": {},
                      "messageHandlers": {
                        "before:prepare": function anonymous(
) {

x1 = -120
y1 = -120
x2 = -40
y2 = -120
x3 = +40
y3 = -120
x4 = +120
y4 = -120
x5 = -120
y5 = -40
x6 = -40
y6 = -40
x7 = +40
y7 = -40
x8 = +120
y8 = -40
x9 = -120
y9 = +40
x10 = -40
y10 = +40
x11 = +40
y11 = +40
x12 = +120
y12 = +40
x13 = -120
y13 = +120
x14 = -40
y14 = +120
x15 = +40
y15 = +120
x16 = +120
y16 = +120
}
                      },
                      "title": "Inter-Stim Screen",
                      "tardy": true,
                      "timeout": "1000"
                    },
                    {
                      "type": "lab.canvas.Screen",
                      "content": [
                        {
                          "type": "rect",
                          "left": "${x1}",
                          "top": "${y1}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x2}",
                          "top": "${y2}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x3}",
                          "top": "${y3}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x4}",
                          "top": "${y4}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x5}",
                          "top": "${y5}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x6}",
                          "top": "${x6}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x7}",
                          "top": "${y7}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x8}",
                          "top": "${y8}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x9}",
                          "top": "${y9}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x10}",
                          "top": "${y10}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x11}",
                          "top": "${y11}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x12}",
                          "top": "${y12}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x13}",
                          "top": "${y13}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x14}",
                          "top": "${y14}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x15}",
                          "top": "${y15}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x16}",
                          "top": "${y16}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "i-text",
                          "left": "${window.loc[0]}",
                          "top": "${window.loc[1]}",
                          "angle": 0,
                          "width": 224.16,
                          "height": 36.16,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "black",
                          "text": "${window.letter}",
                          "fontStyle": "normal",
                          "fontWeight": "normal",
                          "fontSize": 32,
                          "fontFamily": "sans-serif",
                          "lineHeight": 1.16,
                          "textAlign": "center"
                        }
                      ],
                      "viewport": [
                        800,
                        600
                      ],
                      "files": {},
                      "responses": {
                        "": ""
                      },
                      "parameters": {},
                      "messageHandlers": {
                        "before:prepare": function anonymous(
) {
x1 = -120
y1 = -120
x2 = -40
y2 = -120
x3 = +40
y3 = -120
x4 = +120
y4 = -120
x5 = -120
y5 = -40
x6 = -40
y6 = -40
x7 = +40
y7 = -40
x8 = +120
y8 = -40
x9 = -120
y9 = +40
x10 = -40
y10 = +40
x11 = +40
y11 = +40
x12 = +120
y12 = +40
x13 = -120
y13 = +120
x14 = -40
y14 = +120
x15 = +40
y15 = +120
x16 = +120
y16 = +120
}
                      },
                      "title": "Stimulus Screen",
                      "tardy": true,
                      "timeout": "1000"
                    }
                  ]
                }
              },
              {
                "type": "lab.flow.Loop",
                "templateParameters": [
                  {
                    "": ""
                  }
                ],
                "sample": {
                  "mode": "draw-shuffle",
                  "n": "${window.updSteps}"
                },
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "UpdatingLoop",
                "shuffleGroups": [],
                "template": {
                  "type": "lab.flow.Sequence",
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {
                    "before:prepare": function anonymous(
) {
// get letter for current position
window.letter = window.updOps_char[window.updatingStep] 

// get location for current position
window.loc_num = window.updOps_loc[window.updatingStep]
window.loc = window.locs[window.loc_num-1]

// Print out some information if necessary
//console.log('Current Stimulus: ', window.letter)
//console.log('Current Locations: ' , window.loc)

//console.log("Current Position: ", window.encodingposition)
++window.updatingStep
//console.log("Next Position: ", window.encodingposition)
}
                  },
                  "title": "UpdatingSequence",
                  "tardy": true,
                  "content": [
                    {
                      "type": "lab.canvas.Screen",
                      "content": [
                        {
                          "type": "rect",
                          "left": "${x1}",
                          "top": "${y1}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x2}",
                          "top": "${y2}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x3}",
                          "top": "${y3}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x4}",
                          "top": "${y4}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x5}",
                          "top": "${y5}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x6}",
                          "top": "${x6}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x7}",
                          "top": "${y7}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x8}",
                          "top": "${y8}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x9}",
                          "top": "${y9}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x10}",
                          "top": "${y10}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x11}",
                          "top": "${y11}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x12}",
                          "top": "${y12}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x13}",
                          "top": "${y13}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x14}",
                          "top": "${y14}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x15}",
                          "top": "${y15}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x16}",
                          "top": "${y16}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        }
                      ],
                      "viewport": [
                        800,
                        600
                      ],
                      "files": {},
                      "responses": {
                        "": ""
                      },
                      "parameters": {},
                      "messageHandlers": {
                        "before:prepare": function anonymous(
) {

x1 = -120
y1 = -120
x2 = -40
y2 = -120
x3 = +40
y3 = -120
x4 = +120
y4 = -120
x5 = -120
y5 = -40
x6 = -40
y6 = -40
x7 = +40
y7 = -40
x8 = +120
y8 = -40
x9 = -120
y9 = +40
x10 = -40
y10 = +40
x11 = +40
y11 = +40
x12 = +120
y12 = +40
x13 = -120
y13 = +120
x14 = -40
y14 = +120
x15 = +40
y15 = +120
x16 = +120
y16 = +120
}
                      },
                      "title": "Inter-Stim Screen",
                      "tardy": true,
                      "timeout": "1000"
                    },
                    {
                      "type": "lab.canvas.Screen",
                      "content": [
                        {
                          "type": "rect",
                          "left": "${x1}",
                          "top": "${y1}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x2}",
                          "top": "${y2}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x3}",
                          "top": "${y3}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x4}",
                          "top": "${y4}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x5}",
                          "top": "${y5}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x6}",
                          "top": "${x6}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x7}",
                          "top": "${y7}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x8}",
                          "top": "${y8}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x9}",
                          "top": "${y9}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x10}",
                          "top": "${y10}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x11}",
                          "top": "${y11}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x12}",
                          "top": "${y12}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x13}",
                          "top": "${y13}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x14}",
                          "top": "${y14}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x15}",
                          "top": "${y15}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x16}",
                          "top": "${y16}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "i-text",
                          "left": "${window.loc[0]}",
                          "top": "${window.loc[1]}",
                          "angle": 0,
                          "width": 224.16,
                          "height": 36.16,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "black",
                          "text": "${window.letter}",
                          "fontStyle": "normal",
                          "fontWeight": "normal",
                          "fontSize": 32,
                          "fontFamily": "sans-serif",
                          "lineHeight": 1.16,
                          "textAlign": "center"
                        }
                      ],
                      "viewport": [
                        800,
                        600
                      ],
                      "files": {},
                      "responses": {
                        "": ""
                      },
                      "parameters": {},
                      "messageHandlers": {
                        "before:prepare": function anonymous(
) {
x1 = -120
y1 = -120
x2 = -40
y2 = -120
x3 = +40
y3 = -120
x4 = +120
y4 = -120
x5 = -120
y5 = -40
x6 = -40
y6 = -40
x7 = +40
y7 = -40
x8 = +120
y8 = -40
x9 = -120
y9 = +40
x10 = -40
y10 = +40
x11 = +40
y11 = +40
x12 = +120
y12 = +40
x13 = -120
y13 = +120
x14 = -40
y14 = +120
x15 = +40
y15 = +120
x16 = +120
y16 = +120
}
                      },
                      "title": "Stimulus Screen",
                      "tardy": true,
                      "timeout": "1000"
                    }
                  ]
                }
              },
              {
                "type": "lab.canvas.Screen",
                "content": [],
                "viewport": [
                  800,
                  600
                ],
                "files": {},
                "responses": {},
                "parameters": {},
                "messageHandlers": {},
                "title": "Retention Interval",
                "tardy": true,
                "timeout": "1000"
              },
              {
                "type": "lab.flow.Loop",
                "templateParameters": [
                  {
                    "": ""
                  }
                ],
                "sample": {
                  "mode": "sequential",
                  "n": "${window.setsize}"
                },
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "Recall Loop",
                "shuffleGroups": [],
                "template": {
                  "type": "lab.flow.Sequence",
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {
                    "before:prepare": function anonymous(
) {
// get current retrieval Positions
window.retPos = window.retOrder[retrievalposition]

// get location for current position
window.loc_num = window.encLocations[window.retPos -1]

// Show retrieval cue
// either show stimulus above the grid -> recall location
// or show location cue -> recall stimulus
if(window.rec == "location"){
  window.recallInst = "Please recall the location the letter was presented at."
  window.retrieval = '? ' + window.stimuli[window.retPos-1]
  window.loc = [0,200]
  window.correctResp = window.loc_num.toString()
}else if(window.rec == "stimulus"){
  window.recallInst = "Bitte erinnern Sie sich an die Ziffer, die Sie an der markierten Stelle gespeichert haben."
  window.retrieval = '?' 
  window.loc = window.locs[window.loc_num-1]
  correctResp = window.finalStims[window.retPos-1]
  window.correctResp = correctResp.toString()
}

++window.retrievalposition

}
                  },
                  "title": "Recall Sequence",
                  "tardy": true,
                  "content": [
                    {
                      "type": "lab.canvas.Screen",
                      "content": [
                        {
                          "type": "rect",
                          "left": "${x1}",
                          "top": "${y1}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x2}",
                          "top": "${y2}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x3}",
                          "top": "${y3}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x4}",
                          "top": "${y4}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x5}",
                          "top": "${y5}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x6}",
                          "top": "${x6}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x7}",
                          "top": "${y7}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x8}",
                          "top": "${y8}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x9}",
                          "top": "${y9}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x10}",
                          "top": "${y10}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x11}",
                          "top": "${y11}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x12}",
                          "top": "${y12}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x13}",
                          "top": "${y13}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x14}",
                          "top": "${y14}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x15}",
                          "top": "${y15}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x16}",
                          "top": "${y16}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "i-text",
                          "left": "${window.loc[0]}",
                          "top": "${window.loc[1]}",
                          "angle": 0,
                          "width": 266.83,
                          "height": 36.16,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "black",
                          "text": "${window.retrieval}",
                          "fontStyle": "normal",
                          "fontWeight": "normal",
                          "fontSize": 32,
                          "fontFamily": "sans-serif",
                          "lineHeight": 1.16,
                          "textAlign": "center"
                        },
                        {
                          "type": "aoi",
                          "left": "${x1}",
                          "top": "${y1}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos1"
                        },
                        {
                          "type": "aoi",
                          "left": "${x2}",
                          "top": "${y2}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos2"
                        },
                        {
                          "type": "aoi",
                          "left": "${x3}",
                          "top": "${y3}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos3"
                        },
                        {
                          "type": "aoi",
                          "left": "${x4}",
                          "top": "${y4}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos4"
                        },
                        {
                          "type": "aoi",
                          "left": "${x5}",
                          "top": "${y5}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos5"
                        },
                        {
                          "type": "aoi",
                          "left": "${x6}",
                          "top": "${y6}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos6"
                        },
                        {
                          "type": "aoi",
                          "left": "${x7}",
                          "top": "${y7}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos7"
                        },
                        {
                          "type": "aoi",
                          "left": "${x8}",
                          "top": "${y8}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos8"
                        },
                        {
                          "type": "aoi",
                          "left": "${x9}",
                          "top": "${y9}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos9"
                        },
                        {
                          "type": "aoi",
                          "left": "${x10}",
                          "top": "${y10}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos10"
                        },
                        {
                          "type": "aoi",
                          "left": "${x11}",
                          "top": "${y11}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos11"
                        },
                        {
                          "type": "aoi",
                          "left": "${x12}",
                          "top": "${y12}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos12"
                        },
                        {
                          "type": "aoi",
                          "left": "${x13}",
                          "top": "${y13}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos13"
                        },
                        {
                          "type": "aoi",
                          "left": "${x14}",
                          "top": "${y14}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos14"
                        },
                        {
                          "type": "aoi",
                          "left": "${x15}",
                          "top": "${y15}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos15"
                        },
                        {
                          "type": "aoi",
                          "left": "${x16}",
                          "top": "${y16}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos16"
                        },
                        {
                          "type": "i-text",
                          "left": 0,
                          "top": -220,
                          "angle": 0,
                          "width": 281.06,
                          "height": 36.16,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "black",
                          "text": "${window.recallInst}",
                          "fontStyle": "normal",
                          "fontWeight": "normal",
                          "fontSize": 32,
                          "fontFamily": "sans-serif",
                          "lineHeight": 1.16,
                          "textAlign": "center"
                        }
                      ],
                      "viewport": [
                        800,
                        600
                      ],
                      "files": {},
                      "responses": {
                        "keypress(1)": "1",
                        "keypress(2)": "2",
                        "keypress(3)": "3",
                        "keypress(4)": "4",
                        "keypress(5)": "5",
                        "keypress(6)": "6",
                        "keypress(7)": "7",
                        "keypress(8)": "8",
                        "keypress(9)": "9"
                      },
                      "parameters": {},
                      "messageHandlers": {
                        "before:prepare": function anonymous(
) {
x1 = -120
y1 = -120
x2 = -40
y2 = -120
x3 = +40
y3 = -120
x4 = +120
y4 = -120
x5 = -120
y5 = -40
x6 = -40
y6 = -40
x7 = +40
y7 = -40
x8 = +120
y8 = -40
x9 = -120
y9 = +40
x10 = -40
y10 = +40
x11 = +40
y11 = +40
x12 = +120
y12 = +40
x13 = -120
y13 = +120
x14 = -40
y14 = +120
x15 = +40
y15 = +120
x16 = +120
y16 = +120


},
                        "end": function anonymous(
) {
// data saving
this.data.block = "prac"
this.data.trialNum = window.prac_trial_ind
this.data.setsize = window.setsize
this.data.whatRet = window.rec
this.data.encPos = window.retPos
this.data.retPos = retrievalposition
this.data.encStim = window.encStimuli[window.retPos-1]
this.data.finalStim = window.window.finalStims[window.retPos-1]
this.data.spatPos = window.encLocations[window.retPos -1]
this.data.participant_id = window.participant_id

// code feedback
if (this.data.response === window.correctResp) {
  window.color = "green"
  window.text = "richtig"
} else {
  window.color = "red"
  window.text = "falsch"
}

}
                      },
                      "title": "Retrieval Screen",
                      "tardy": true,
                      "correctResponse": "${window.correctResp}"
                    },
                    {
                      "type": "lab.html.Screen",
                      "files": {},
                      "responses": {
                        "": ""
                      },
                      "parameters": {},
                      "messageHandlers": {},
                      "title": "Feedback",
                      "content": "\u003Cstyle\u003E\n#div1{width: 700px;text-align:  content-horizontal-center;}\n#div2{width: 700px;text-align:  content-horizontal-center content-vertical-center;}\nheader{ padding: 5px; height: 100px;}\nfooter{ padding: 5px; height: 100px;}\n\n\u003C\u002Fstyle\u003E\n\n\n\u003Cmain class=\"content-horizontal-center content-vertical-center\"\u003E \n  \u003Cdiv id = \"#div1\" style = \"font-size: 200%; text-align: content-horizontal-center\"\u003E\n    \u003Cp\u003E Ihre Antwort war: \u003C\u002Fp\u003E\n    \u003Cp\u003E\u003Cstrong\u003E\u003Cspan style=\"color: ${window.color}\"\u003E ${ window.text } \u003C\u002Fspan\u003E \u003C\u002Fstrong\u003E \u003C\u002Fp\u003E\n  \u003C\u002Fdiv\u003E\n\u003C\u002Fmain\u003E\n",
                      "timeout": "1000",
                      "tardy": true
                    },
                    {
                      "type": "lab.canvas.Screen",
                      "content": [],
                      "viewport": [
                        800,
                        600
                      ],
                      "files": {},
                      "responses": {
                        "": ""
                      },
                      "parameters": {},
                      "messageHandlers": {},
                      "title": "RetrievalPause",
                      "timeout": "1000"
                    }
                  ]
                }
              },
              {
                "type": "lab.canvas.Screen",
                "content": [
                  {
                    "type": "i-text",
                    "left": 0,
                    "top": 0,
                    "angle": 0,
                    "width": 663.5,
                    "height": 162,
                    "stroke": null,
                    "strokeWidth": 1,
                    "fill": "black",
                    "text": "Dies ist das Ende eines Durchgangs.\n\nBitte drücken Sie die „Leertaste“, \num mit dem nächsten Durchgang zu beginnen.",
                    "fontStyle": "normal",
                    "fontWeight": "normal",
                    "fontSize": 32,
                    "fontFamily": "sans-serif",
                    "lineHeight": 1.16,
                    "textAlign": "center"
                  }
                ],
                "viewport": [
                  800,
                  600
                ],
                "files": {},
                "responses": {
                  "keypress(Space)": "Continue"
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "TrialEnd"
              }
            ]
          }
        },
        {
          "type": "lab.canvas.Screen",
          "content": [
            {
              "type": "i-text",
              "left": 0,
              "top": 0,
              "angle": 0,
              "width": 660.06,
              "height": 184.42,
              "stroke": null,
              "strokeWidth": 1,
              "fill": "black",
              "text": "Dies waren die Übungsdurchgänge.  \nIm folgenden Experiment werde Sie keine Rückmeldung \nmehr erhalten.\n\nWenn Sie bereit sind, \nmit dem Experiment zu beginnen, drücken Sie die \"Leertaste\".",
              "fontStyle": "normal",
              "fontWeight": "normal",
              "fontSize": "24",
              "fontFamily": "sans-serif",
              "lineHeight": 1.16,
              "textAlign": "center"
            }
          ],
          "viewport": [
            800,
            600
          ],
          "files": {},
          "responses": {
            "keypress(Space)": "End"
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "StartExp_Inst"
        },
        {
          "type": "lab.flow.Loop",
          "templateParameters": [
            {
              "": ""
            }
          ],
          "sample": {
            "mode": "sequential",
            "n": "${window.numTrials}"
          },
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "Trial Loop",
          "shuffleGroups": [],
          "template": {
            "type": "lab.flow.Sequence",
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {
              "before:prepare": function anonymous(
) {
this_trial = window.final_trial_list[window.trial_ind]

// initialize the encoding and retrieval positions
window.encodingposition = 0
window.retrievalposition = 0
window.updatingStep = 0

// make trial variables available in each trial
window.setsize = this_trial[0]
window.rec = this_trial[1]
window.encStimuli = this_trial[2]
window.encLocations = this_trial[3]
window.encOrder = this_trial[4]
window.retOrder = this_trial[5]

window.updSteps = this_trial[6]
window.updOps_char = this_trial[8]
window.updOps_loc = []
for(k = 0; k < window.updSteps; ++k){
  upd_Locs = this_trial[9]
  loc_Idx = upd_Locs[k]
  window.updOps_loc[k] = window.encLocations[loc_Idx]
}
window.finalStims = this_trial[10]

// iterate to the next trial
++window.trial_ind
}
            },
            "title": "Trial Sequence",
            "tardy": true,
            "content": [
              {
                "type": "lab.canvas.Screen",
                "content": [],
                "viewport": [
                  800,
                  600
                ],
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "StartTrialBlank",
                "timeout": "1000"
              },
              {
                "type": "lab.flow.Loop",
                "templateParameters": [
                  {
                    "": ""
                  }
                ],
                "sample": {
                  "mode": "sequential",
                  "n": "${window.setsize}"
                },
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "Encoding Loop",
                "shuffleGroups": [],
                "template": {
                  "type": "lab.flow.Sequence",
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {
                    "before:prepare": function anonymous(
) {
// extract encoding position
window.encPos = window.encOrder[encodingposition]

// get letter for current position
window.letter = window.encStimuli[window.encPos -1] 

// get location for current position
window.loc_num = window.encLocations[window.encPos -1]
window.loc = window.locs[window.loc_num-1]

// Print out some information if necessary
//console.log('Current Stimulus: ', window.letter)
//console.log('Current Locations: ' , window.loc)

//console.log("Current Position: ", window.encodingposition)
++window.encodingposition
//console.log("Next Position: ", window.encodingposition)
}
                  },
                  "title": "Encoding Sequence",
                  "tardy": true,
                  "content": [
                    {
                      "type": "lab.canvas.Screen",
                      "content": [
                        {
                          "type": "rect",
                          "left": "${x1}",
                          "top": "${y1}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x2}",
                          "top": "${y2}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x3}",
                          "top": "${y3}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x4}",
                          "top": "${y4}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x5}",
                          "top": "${y5}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x6}",
                          "top": "${x6}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x7}",
                          "top": "${y7}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x8}",
                          "top": "${y8}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x9}",
                          "top": "${y9}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x10}",
                          "top": "${y10}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x11}",
                          "top": "${y11}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x12}",
                          "top": "${y12}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x13}",
                          "top": "${y13}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x14}",
                          "top": "${y14}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x15}",
                          "top": "${y15}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x16}",
                          "top": "${y16}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        }
                      ],
                      "viewport": [
                        800,
                        600
                      ],
                      "files": {},
                      "responses": {
                        "": ""
                      },
                      "parameters": {},
                      "messageHandlers": {
                        "before:prepare": function anonymous(
) {

x1 = -120
y1 = -120
x2 = -40
y2 = -120
x3 = +40
y3 = -120
x4 = +120
y4 = -120
x5 = -120
y5 = -40
x6 = -40
y6 = -40
x7 = +40
y7 = -40
x8 = +120
y8 = -40
x9 = -120
y9 = +40
x10 = -40
y10 = +40
x11 = +40
y11 = +40
x12 = +120
y12 = +40
x13 = -120
y13 = +120
x14 = -40
y14 = +120
x15 = +40
y15 = +120
x16 = +120
y16 = +120
}
                      },
                      "title": "Inter-Stim Screen",
                      "tardy": true,
                      "timeout": "1000"
                    },
                    {
                      "type": "lab.canvas.Screen",
                      "content": [
                        {
                          "type": "rect",
                          "left": "${x1}",
                          "top": "${y1}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x2}",
                          "top": "${y2}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x3}",
                          "top": "${y3}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x4}",
                          "top": "${y4}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x5}",
                          "top": "${y5}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x6}",
                          "top": "${x6}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x7}",
                          "top": "${y7}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x8}",
                          "top": "${y8}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x9}",
                          "top": "${y9}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x10}",
                          "top": "${y10}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x11}",
                          "top": "${y11}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x12}",
                          "top": "${y12}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x13}",
                          "top": "${y13}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x14}",
                          "top": "${y14}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x15}",
                          "top": "${y15}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x16}",
                          "top": "${y16}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "i-text",
                          "left": "${window.loc[0]}",
                          "top": "${window.loc[1]}",
                          "angle": 0,
                          "width": 224.16,
                          "height": 36.16,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "black",
                          "text": "${window.letter}",
                          "fontStyle": "normal",
                          "fontWeight": "normal",
                          "fontSize": 32,
                          "fontFamily": "sans-serif",
                          "lineHeight": 1.16,
                          "textAlign": "center"
                        }
                      ],
                      "viewport": [
                        800,
                        600
                      ],
                      "files": {},
                      "responses": {
                        "": ""
                      },
                      "parameters": {},
                      "messageHandlers": {
                        "before:prepare": function anonymous(
) {
x1 = -120
y1 = -120
x2 = -40
y2 = -120
x3 = +40
y3 = -120
x4 = +120
y4 = -120
x5 = -120
y5 = -40
x6 = -40
y6 = -40
x7 = +40
y7 = -40
x8 = +120
y8 = -40
x9 = -120
y9 = +40
x10 = -40
y10 = +40
x11 = +40
y11 = +40
x12 = +120
y12 = +40
x13 = -120
y13 = +120
x14 = -40
y14 = +120
x15 = +40
y15 = +120
x16 = +120
y16 = +120
}
                      },
                      "title": "Stimulus Screen",
                      "tardy": true,
                      "timeout": "1000"
                    }
                  ]
                }
              },
              {
                "type": "lab.flow.Loop",
                "templateParameters": [
                  {
                    "": ""
                  }
                ],
                "sample": {
                  "mode": "draw-shuffle",
                  "n": "${window.updSteps}"
                },
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "UpdatingLoop",
                "shuffleGroups": [],
                "template": {
                  "type": "lab.flow.Sequence",
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {
                    "before:prepare": function anonymous(
) {
// get letter for current position
window.letter = window.updOps_char[window.updatingStep] 

// get location for current position
window.loc_num = window.updOps_loc[window.updatingStep]
window.loc = window.locs[window.loc_num-1]

// Print out some information if necessary
//console.log('Current Stimulus: ', window.letter)
//console.log('Current Locations: ' , window.loc)

//console.log("Current Position: ", window.encodingposition)
++window.updatingStep
//console.log("Next Position: ", window.encodingposition)
}
                  },
                  "title": "UpdatingSequence",
                  "tardy": true,
                  "content": [
                    {
                      "type": "lab.canvas.Screen",
                      "content": [
                        {
                          "type": "rect",
                          "left": "${x1}",
                          "top": "${y1}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x2}",
                          "top": "${y2}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x3}",
                          "top": "${y3}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x4}",
                          "top": "${y4}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x5}",
                          "top": "${y5}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x6}",
                          "top": "${x6}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x7}",
                          "top": "${y7}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x8}",
                          "top": "${y8}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x9}",
                          "top": "${y9}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x10}",
                          "top": "${y10}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x11}",
                          "top": "${y11}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x12}",
                          "top": "${y12}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x13}",
                          "top": "${y13}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x14}",
                          "top": "${y14}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x15}",
                          "top": "${y15}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x16}",
                          "top": "${y16}",
                          "angle": 0,
                          "width": "80",
                          "height": "80",
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        }
                      ],
                      "viewport": [
                        800,
                        600
                      ],
                      "files": {},
                      "responses": {
                        "": ""
                      },
                      "parameters": {},
                      "messageHandlers": {
                        "before:prepare": function anonymous(
) {

x1 = -120
y1 = -120
x2 = -40
y2 = -120
x3 = +40
y3 = -120
x4 = +120
y4 = -120
x5 = -120
y5 = -40
x6 = -40
y6 = -40
x7 = +40
y7 = -40
x8 = +120
y8 = -40
x9 = -120
y9 = +40
x10 = -40
y10 = +40
x11 = +40
y11 = +40
x12 = +120
y12 = +40
x13 = -120
y13 = +120
x14 = -40
y14 = +120
x15 = +40
y15 = +120
x16 = +120
y16 = +120
}
                      },
                      "title": "Inter-Stim Screen",
                      "tardy": true,
                      "timeout": "1000"
                    },
                    {
                      "type": "lab.canvas.Screen",
                      "content": [
                        {
                          "type": "rect",
                          "left": "${x1}",
                          "top": "${y1}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x2}",
                          "top": "${y2}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x3}",
                          "top": "${y3}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x4}",
                          "top": "${y4}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x5}",
                          "top": "${y5}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x6}",
                          "top": "${x6}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x7}",
                          "top": "${y7}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x8}",
                          "top": "${y8}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x9}",
                          "top": "${y9}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x10}",
                          "top": "${y10}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x11}",
                          "top": "${y11}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x12}",
                          "top": "${y12}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x13}",
                          "top": "${y13}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x14}",
                          "top": "${y14}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x15}",
                          "top": "${y15}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x16}",
                          "top": "${y16}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "i-text",
                          "left": "${window.loc[0]}",
                          "top": "${window.loc[1]}",
                          "angle": 0,
                          "width": 224.16,
                          "height": 36.16,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "black",
                          "text": "${window.letter}",
                          "fontStyle": "normal",
                          "fontWeight": "normal",
                          "fontSize": 32,
                          "fontFamily": "sans-serif",
                          "lineHeight": 1.16,
                          "textAlign": "center"
                        }
                      ],
                      "viewport": [
                        800,
                        600
                      ],
                      "files": {},
                      "responses": {
                        "": ""
                      },
                      "parameters": {},
                      "messageHandlers": {
                        "before:prepare": function anonymous(
) {
x1 = -120
y1 = -120
x2 = -40
y2 = -120
x3 = +40
y3 = -120
x4 = +120
y4 = -120
x5 = -120
y5 = -40
x6 = -40
y6 = -40
x7 = +40
y7 = -40
x8 = +120
y8 = -40
x9 = -120
y9 = +40
x10 = -40
y10 = +40
x11 = +40
y11 = +40
x12 = +120
y12 = +40
x13 = -120
y13 = +120
x14 = -40
y14 = +120
x15 = +40
y15 = +120
x16 = +120
y16 = +120
}
                      },
                      "title": "Stimulus Screen",
                      "tardy": true,
                      "timeout": "1000"
                    }
                  ]
                }
              },
              {
                "type": "lab.canvas.Screen",
                "content": [],
                "viewport": [
                  800,
                  600
                ],
                "files": {},
                "responses": {},
                "parameters": {},
                "messageHandlers": {},
                "title": "Retention Interval",
                "tardy": true,
                "timeout": "1000"
              },
              {
                "type": "lab.flow.Loop",
                "templateParameters": [
                  {
                    "": ""
                  }
                ],
                "sample": {
                  "mode": "sequential",
                  "n": "${window.setsize}"
                },
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "Recall Loop",
                "shuffleGroups": [],
                "template": {
                  "type": "lab.flow.Sequence",
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {
                    "before:prepare": function anonymous(
) {
// get current retrieval Positions
window.retPos = window.retOrder[retrievalposition]

// get location for current position
window.loc_num = window.encLocations[window.retPos -1]

// Show retrieval cue
// either show stimulus above the grid -> recall location
// or show location cue -> recall stimulus
if(window.rec == "location"){
  window.recallInst = "Please recall the location the letter was presented at."
  window.retrieval = '? ' + window.stimuli[window.retPos-1]
  window.loc = [0,200]
  window.correctResp = window.loc_num.toString()
}else if(window.rec == "stimulus"){
  window.recallInst = "Bitte erinnern Sie sich an die Ziffer, die Sie an der markierten Stelle gespeichert haben."
  window.retrieval = '?' 
  window.loc = window.locs[window.loc_num-1]
  correctResp = window.finalStims[window.retPos-1]
  window.correctResp = correctResp.toString()
}

++window.retrievalposition
}
                  },
                  "title": "Recall Sequence",
                  "tardy": true,
                  "content": [
                    {
                      "type": "lab.canvas.Screen",
                      "content": [
                        {
                          "type": "rect",
                          "left": "${x1}",
                          "top": "${y1}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x2}",
                          "top": "${y2}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x3}",
                          "top": "${y3}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x4}",
                          "top": "${y4}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x5}",
                          "top": "${y5}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x6}",
                          "top": "${x6}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x7}",
                          "top": "${y7}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x8}",
                          "top": "${y8}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x9}",
                          "top": "${y9}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x10}",
                          "top": "${y10}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x11}",
                          "top": "${y11}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x12}",
                          "top": "${y12}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x13}",
                          "top": "${y13}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x14}",
                          "top": "${y14}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x15}",
                          "top": "${y15}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "rect",
                          "left": "${x16}",
                          "top": "${y16}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": "#000000",
                          "strokeWidth": 1,
                          "fill": "transparent"
                        },
                        {
                          "type": "i-text",
                          "left": "${window.loc[0]}",
                          "top": "${window.loc[1]}",
                          "angle": 0,
                          "width": 266.83,
                          "height": 36.16,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "black",
                          "text": "${window.retrieval}",
                          "fontStyle": "normal",
                          "fontWeight": "normal",
                          "fontSize": 32,
                          "fontFamily": "sans-serif",
                          "lineHeight": 1.16,
                          "textAlign": "center"
                        },
                        {
                          "type": "aoi",
                          "left": "${x1}",
                          "top": "${y1}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos1"
                        },
                        {
                          "type": "aoi",
                          "left": "${x2}",
                          "top": "${y2}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos2"
                        },
                        {
                          "type": "aoi",
                          "left": "${x3}",
                          "top": "${y3}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos3"
                        },
                        {
                          "type": "aoi",
                          "left": "${x4}",
                          "top": "${y4}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos4"
                        },
                        {
                          "type": "aoi",
                          "left": "${x5}",
                          "top": "${y5}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos5"
                        },
                        {
                          "type": "aoi",
                          "left": "${x6}",
                          "top": "${y6}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos6"
                        },
                        {
                          "type": "aoi",
                          "left": "${x7}",
                          "top": "${y7}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos7"
                        },
                        {
                          "type": "aoi",
                          "left": "${x8}",
                          "top": "${y8}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos8"
                        },
                        {
                          "type": "aoi",
                          "left": "${x9}",
                          "top": "${y9}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos9"
                        },
                        {
                          "type": "aoi",
                          "left": "${x10}",
                          "top": "${y10}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos10"
                        },
                        {
                          "type": "aoi",
                          "left": "${x11}",
                          "top": "${y11}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos11"
                        },
                        {
                          "type": "aoi",
                          "left": "${x12}",
                          "top": "${y12}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos12"
                        },
                        {
                          "type": "aoi",
                          "left": "${x13}",
                          "top": "${y13}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos13"
                        },
                        {
                          "type": "aoi",
                          "left": "${x14}",
                          "top": "${y14}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos14"
                        },
                        {
                          "type": "aoi",
                          "left": "${x15}",
                          "top": "${y15}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos15"
                        },
                        {
                          "type": "aoi",
                          "left": "${x16}",
                          "top": "${y16}",
                          "angle": 0,
                          "width": 80,
                          "height": 80,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "rgba(0, 0, 0, 0.2)",
                          "label": "Pos16"
                        },
                        {
                          "type": "i-text",
                          "left": 0,
                          "top": -220,
                          "angle": 0,
                          "width": 281.06,
                          "height": 36.16,
                          "stroke": null,
                          "strokeWidth": 1,
                          "fill": "black",
                          "text": "${window.recallInst}",
                          "fontStyle": "normal",
                          "fontWeight": "normal",
                          "fontSize": 32,
                          "fontFamily": "sans-serif",
                          "lineHeight": 1.16,
                          "textAlign": "center"
                        }
                      ],
                      "viewport": [
                        800,
                        600
                      ],
                      "files": {},
                      "responses": {
                        "keypress(1)": "1",
                        "keypress(2)": "2",
                        "keypress(3)": "3",
                        "keypress(4)": "4",
                        "keypress(5)": "5",
                        "keypress(6)": "6",
                        "keypress(7)": "7",
                        "keypress(8)": "8",
                        "keypress(9)": "9"
                      },
                      "parameters": {},
                      "messageHandlers": {
                        "before:prepare": function anonymous(
) {
x1 = -120
y1 = -120
x2 = -40
y2 = -120
x3 = +40
y3 = -120
x4 = +120
y4 = -120
x5 = -120
y5 = -40
x6 = -40
y6 = -40
x7 = +40
y7 = -40
x8 = +120
y8 = -40
x9 = -120
y9 = +40
x10 = -40
y10 = +40
x11 = +40
y11 = +40
x12 = +120
y12 = +40
x13 = -120
y13 = +120
x14 = -40
y14 = +120
x15 = +40
y15 = +120
x16 = +120
y16 = +120
},
                        "end": function anonymous(
) {
// data saving
this.data.block = "exp"
this.data.trialNum = window.trial_ind
this.data.setsize = window.setsize
this.data.whatRet = window.rec
this.data.encPos = window.retPos
this.data.retPos = retrievalposition
this.data.encStim = window.encStimuli[window.retPos-1]
this.data.finalStim = window.window.finalStims[window.retPos-1]
this.data.spatPos = window.encLocations[window.retPos -1]
this.data.participant_id = window.participant_id

// code feedback
if (this.data.response === window.correctResp.toString()) {
  window.color = "green"
  window.text = "correct"
} else {
  window.color = "red"
  window.text = "incorrect"
}
}
                      },
                      "title": "Retrieval Screen",
                      "tardy": true,
                      "correctResponse": "${window.correctResp}"
                    },
                    {
                      "type": "lab.canvas.Screen",
                      "content": [],
                      "viewport": [
                        800,
                        600
                      ],
                      "files": {},
                      "responses": {
                        "": ""
                      },
                      "parameters": {},
                      "messageHandlers": {},
                      "title": "RetrievalPause",
                      "timeout": "1000"
                    }
                  ]
                }
              },
              {
                "type": "lab.canvas.Screen",
                "content": [
                  {
                    "type": "i-text",
                    "left": 0,
                    "top": 0,
                    "angle": 0,
                    "width": 663.5,
                    "height": 162,
                    "stroke": null,
                    "strokeWidth": 1,
                    "fill": "black",
                    "text": "Dies ist das Ende eines Durchgangs.\n\nBitte drücken Sie die „Leertaste“, \num mit dem nächsten Durchgang zu beginnen.",
                    "fontStyle": "normal",
                    "fontWeight": "normal",
                    "fontSize": 32,
                    "fontFamily": "sans-serif",
                    "lineHeight": 1.16,
                    "textAlign": "center"
                  }
                ],
                "viewport": [
                  800,
                  600
                ],
                "files": {},
                "responses": {
                  "keypress(Space)": "Continue"
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "TrialEnd"
              }
            ]
          }
        }
      ]
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 548.3,
          "height": 121.5,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Dies ist das Ende der Numerical Updating Aufgabe.\n\nUm mit der nächsten Aufgabe fortzufahren, \ndrücken Sie bitte die \"Leertaste\".",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": "24",
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress(Space)": "End"
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "TaskEnd"
    }
  ]
})

// Let's go!
jatos.onLoad(() => study.run())